import { Router, type IRouter, type RequestHandler } from "express";
import { getAuth } from "@clerk/express";
import {
  GetDashboardActivityResponse,
  GetDashboardSummaryResponse,
  GetDashboardUsersResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

const requireAuth: RequestHandler = (req, res, next) => {
  const auth = getAuth(req);
  const userId = auth?.userId;
  if (!userId) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }
  next();
};

router.get("/dashboard/summary", requireAuth, (req, res) => {
  const data = GetDashboardSummaryResponse.parse({
    metrics: [
      {
        label: "Total revenue",
        value: "$48,290",
        change: "+12.8%",
        trend: "up",
        accent: "blue",
      },
      {
        label: "Active users",
        value: "2,420",
        change: "+8.2%",
        trend: "up",
        accent: "violet",
      },
      {
        label: "Conversion rate",
        value: "6.84%",
        change: "-1.4%",
        trend: "down",
        accent: "amber",
      },
      {
        label: "Avg. session",
        value: "4m 32s",
        change: "+4.6%",
        trend: "up",
        accent: "green",
      },
    ],
    activeUsers: 2420,
    weeklyGoal: 5000,
    weeklyProgress: 64,
  });
  req.log.info("Dashboard summary requested");
  res.json(data);
});

router.get("/dashboard/activity", requireAuth, (req, res) => {
  const data = GetDashboardActivityResponse.parse([
    {
      id: "activity-1",
      actor: "Olivia Rhye",
      initials: "OR",
      action: "published a new report",
      target: "Q3 Growth Analysis",
      timestamp: "12 minutes ago",
      tone: "blue",
    },
    {
      id: "activity-2",
      actor: "Candice Wu",
      initials: "CW",
      action: "invited a new teammate",
      target: "James Alexander",
      timestamp: "48 minutes ago",
      tone: "violet",
    },
    {
      id: "activity-3",
      actor: "Drew Cano",
      initials: "DC",
      action: "completed the setup checklist",
      target: "Workspace onboarding",
      timestamp: "2 hours ago",
      tone: "green",
    },
    {
      id: "activity-4",
      actor: "Phoenix Baker",
      initials: "PB",
      action: "updated billing details",
      target: "Annual plan",
      timestamp: "Yesterday",
      tone: "amber",
    },
  ]);
  req.log.info("Dashboard activity requested");
  res.json(data);
});

router.get("/dashboard/users", requireAuth, (req, res) => {
  const data = GetDashboardUsersResponse.parse([
    {
      id: "user-1",
      name: "Olivia Rhye",
      email: "olivia@untitled.com",
      role: "Administrator",
      status: "active",
      initials: "OR",
    },
    {
      id: "user-2",
      name: "Candice Wu",
      email: "candice@untitled.com",
      role: "Product manager",
      status: "active",
      initials: "CW",
    },
    {
      id: "user-3",
      name: "Drew Cano",
      email: "drew@untitled.com",
      role: "Developer",
      status: "invited",
      initials: "DC",
    },
    {
      id: "user-4",
      name: "Phoenix Baker",
      email: "phoenix@untitled.com",
      role: "Analyst",
      status: "paused",
      initials: "PB",
    },
  ]);
  req.log.info("Dashboard users requested");
  res.json(data);
});

export default router;