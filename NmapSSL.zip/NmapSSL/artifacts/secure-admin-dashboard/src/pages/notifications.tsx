import { useState } from 'react';
import { Bell, Check, CheckCheck } from 'lucide-react';
import { getGetDashboardActivityQueryKey, useGetDashboardActivity } from '@workspace/api-client-react';
import { QueryError, QuerySkeleton, EmptyState } from '@/components/data-states';

export function NotificationsPage() {
  const query = useGetDashboardActivity({ query: { queryKey: getGetDashboardActivityQueryKey() } });
  const [read, setRead] = useState<string[]>([]);
  if (query.isLoading) return <QuerySkeleton lines={5} />;
  if (query.isError) return <QueryError onRetry={() => void query.refetch()} label="Notifications could not be loaded." />;
  const items = query.data || [];
  return <div className="mx-auto max-w-4xl space-y-7">
    <div className="flex items-end justify-between border-b border-border pb-7"><div><p className="font-mono-ui text-[11px] uppercase tracking-[.18em] text-primary">Workspace / inbox</p><h1 className="mt-2 text-3xl font-bold tracking-[-.035em]">Notifications</h1><p className="mt-2 text-sm text-muted-foreground">A quiet log of what changed while you were away.</p></div><button type="button" onClick={() => setRead(items.map((item) => item.id))} className="hidden items-center gap-2 rounded-lg border border-border bg-card px-3 py-2 text-xs font-bold transition-colors hover:bg-muted sm:flex" data-testid="button-mark-all-read"><CheckCheck size={14} /> Mark all read</button></div>
    {items.length ? <div className="surface overflow-hidden rounded-2xl"><div className="divide-y divide-border">{items.map((item) => { const isRead = read.includes(item.id); return <button type="button" key={item.id} onClick={() => setRead((current) => current.includes(item.id) ? current : [...current, item.id])} className={`flex w-full items-start gap-4 px-5 py-5 text-left transition-colors hover:bg-muted/50 sm:px-7 ${isRead ? 'opacity-60' : ''}`} data-testid={`button-notification-${item.id}`}><span className={`mt-0.5 grid size-9 shrink-0 place-items-center rounded-full ${isRead ? 'bg-muted text-muted-foreground' : 'bg-primary/10 text-primary'}`}>{isRead ? <Check size={15} /> : <Bell size={15} />}</span><span className="min-w-0 flex-1"><span className="block text-sm leading-6"><strong>{item.actor}</strong> <span className="text-muted-foreground">{item.action} {item.target}</span></span><span className="mt-1 block text-xs text-muted-foreground">{item.timestamp}</span></span>{!isRead && <span className="mt-2 size-1.5 shrink-0 rounded-full bg-accent" />}</button>; })}</div></div> : <EmptyState title="You’re all caught up" description="New workspace activity will appear here." />}
  </div>;
}