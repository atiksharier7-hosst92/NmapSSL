import { useUser } from '@clerk/react';
import { CalendarDays, Mail, ShieldCheck } from 'lucide-react';

export function ProfilePage() {
  const { user, isLoaded } = useUser();
  if (!isLoaded) return <div className="animate-pulse space-y-4"><div className="h-20 rounded-2xl bg-muted" /><div className="h-52 rounded-2xl bg-muted" /></div>;
  const name = [user?.firstName, user?.lastName].filter(Boolean).join(' ') || user?.username || 'Workspace member';
  const email = user?.primaryEmailAddress?.emailAddress || 'No primary email';
  const initials = (user?.firstName?.[0] || email[0] || 'M').toUpperCase();
  return <div className="mx-auto max-w-3xl space-y-7">
    <div className="border-b border-border pb-7"><p className="font-mono-ui text-[11px] uppercase tracking-[.18em] text-primary">Account / identity</p><h1 className="mt-2 text-3xl font-bold tracking-[-.035em]">My profile</h1><p className="mt-2 text-sm text-muted-foreground">Your identity and access details for this workspace.</p></div>
    <div className="surface rounded-2xl p-6 sm:p-8"><div className="flex flex-col gap-5 sm:flex-row sm:items-center"><span className="grid size-20 place-items-center rounded-2xl bg-primary text-2xl font-bold text-primary-foreground">{initials}</span><div><h2 className="text-2xl font-bold tracking-tight">{name}</h2><p className="mt-1 text-sm text-muted-foreground">{email}</p><span className="mt-3 inline-flex items-center gap-1.5 rounded-full bg-[#dcefe4] px-2.5 py-1 text-[10px] font-bold text-[#2c7453]"><span className="size-1.5 rounded-full bg-[#2c7453]" /> Active account</span></div></div><div className="mt-8 grid gap-4 border-t border-border pt-6 sm:grid-cols-2"><div className="flex items-start gap-3"><Mail size={17} className="mt-0.5 text-primary" /><div><p className="text-xs font-bold uppercase tracking-[.12em] text-muted-foreground">Primary email</p><p className="mt-1 text-sm font-semibold">{email}</p></div></div><div className="flex items-start gap-3"><CalendarDays size={17} className="mt-0.5 text-primary" /><div><p className="text-xs font-bold uppercase tracking-[.12em] text-muted-foreground">Member since</p><p className="mt-1 text-sm font-semibold">{user?.createdAt ? new Date(user.createdAt).toLocaleDateString(undefined, { month: 'long', year: 'numeric' }) : 'Recently'}</p></div></div></div></div>
    <div className="surface rounded-2xl p-6 sm:p-8"><div className="flex items-start gap-3"><span className="grid size-9 place-items-center rounded-xl bg-accent/20 text-[#9a641d]"><ShieldCheck size={17} /></span><div><h2 className="font-bold">Workspace access</h2><p className="mt-1 text-sm leading-6 text-muted-foreground">Your access is managed by the Northstar workspace administrator. Authentication is handled securely by Clerk.</p></div></div></div>
  </div>;
}