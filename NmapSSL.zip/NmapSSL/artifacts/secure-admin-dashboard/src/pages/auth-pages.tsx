import { type ReactNode } from 'react';
import { SignIn, SignUp } from '@clerk/react';
import { BrandMark } from '@/components/brand-mark';

const basePath = import.meta.env.BASE_URL.replace(/\/$/, '');

const appearance = {
  variables: {
    colorPrimary: '#0f6655',
    colorForeground: '#17232e',
    colorMutedForeground: '#718078',
    colorBackground: '#fbfcf8',
    colorInput: '#f3f5ef',
    colorInputForeground: '#17232e',
    colorDanger: '#b3403a',
    colorNeutral: '#dfe5dc',
    fontFamily: 'DM Sans, sans-serif',
    borderRadius: '0.8rem',
  },
  elements: {
    rootBox: 'w-full flex justify-center',
    cardBox: 'bg-[#fbfcf8] rounded-2xl w-[440px] max-w-full overflow-hidden shadow-[0_18px_55px_rgba(38,59,52,.09)]',
    card: '!shadow-none !border-0 !bg-transparent',
    footer: '!shadow-none !border-0 !bg-transparent',
    headerTitle: 'text-[#17232e] font-bold',
    headerSubtitle: 'text-[#718078]',
    socialButtonsBlockButtonText: 'text-[#17232e] font-semibold',
    formFieldLabel: 'text-[#17232e] font-semibold',
    footerActionLink: 'text-[#0f6655] font-semibold',
    footerActionText: 'text-[#718078]',
    dividerText: 'text-[#718078]',
    formButtonPrimary: 'bg-[#0f6655] hover:bg-[#0b5749] text-[#fbfcf8] font-bold',
    formFieldInput: 'bg-[#f3f5ef] border-[#dfe5dc] text-[#17232e]',
    socialButtonsBlockButton: 'border-[#dfe5dc] bg-[#fbfcf8]',
    dividerLine: 'bg-[#dfe5dc]',
    logoBox: 'hidden',
    main: 'gap-5',
  },
};

export function SignInPage() {
  return <AuthFrame><SignIn routing="path" path={`${basePath}/sign-in`} signUpUrl={`${basePath}/sign-up`} appearance={appearance} /></AuthFrame>;
}

export function SignUpPage() {
  return <AuthFrame><SignUp routing="path" path={`${basePath}/sign-up`} signInUrl={`${basePath}/sign-in`} appearance={appearance} /></AuthFrame>;
}

function AuthFrame({ children }: { children: ReactNode }) {
  return (
    <div className="grid min-h-[100dvh] bg-background lg:grid-cols-[.78fr_1.22fr]">
      <div className="relative hidden overflow-hidden bg-primary p-10 text-primary-foreground lg:flex lg:flex-col">
        <div className="absolute -right-24 -top-24 size-72 rounded-full border border-primary-foreground/15" /><div className="absolute -bottom-32 -left-20 size-80 rounded-full bg-accent/10 blur-2xl" />
        <BrandMark />
        <div className="relative mt-auto max-w-md pb-8"><p className="font-mono-ui text-xs uppercase tracking-[.18em] text-accent">Northstar / secure access</p><h1 className="mt-5 text-5xl font-display leading-[.97] tracking-tight">The work is waiting.<br /><em>See it clearly.</em></h1><p className="mt-5 max-w-sm text-sm leading-6 text-primary-foreground/65">A private command center for teams who prefer progress over noise.</p></div>
        <div className="relative flex items-center gap-2 text-xs text-primary-foreground/55"><span className="size-1.5 rounded-full bg-accent" /> Encrypted workspace access</div>
      </div>
      <div className="flex flex-col items-center justify-center px-5 py-10 sm:px-8"><div className="mb-8 lg:hidden"><BrandMark /></div>{children}<p className="mt-6 text-center text-[11px] text-muted-foreground">By continuing, you agree to your workspace’s security policy.</p></div>
    </div>
  );
}