import { useEffect } from 'react';
import { useAuth } from '@clerk/react';
import { ArrowRight, Check, LockKeyhole, Sparkles } from 'lucide-react';
import { Link, useLocation } from 'wouter';
import { BrandMark } from '@/components/brand-mark';

export function HomePage() {
  const { isLoaded, isSignedIn } = useAuth();
  const [, setLocation] = useLocation();
  useEffect(() => {
    if (isLoaded && isSignedIn) setLocation('/dashboard');
  }, [isLoaded, isSignedIn, setLocation]);

  return (
    <div className="min-h-[100dvh] overflow-hidden bg-background">
      <header className="relative z-10 mx-auto flex max-w-7xl items-center justify-between px-5 py-6 sm:px-8 lg:px-10">
        <BrandMark />
        <div className="flex items-center gap-3">
          <span className="hidden text-xs text-muted-foreground sm:inline">Already a member?</span>
          <Link href="/sign-in" className="rounded-xl border border-border bg-card px-4 py-2.5 text-sm font-bold transition-all hover:-translate-y-0.5 hover:border-primary/40 hover:shadow-sm" data-testid="link-home-sign-in">Sign in</Link>
        </div>
      </header>
      <main>
        <section className="relative mx-auto grid max-w-7xl items-center gap-14 px-5 pb-20 pt-14 sm:px-8 md:grid-cols-[1.04fr_.96fr] md:pb-28 md:pt-20 lg:px-10">
          <div className="pointer-events-none absolute -left-44 -top-28 size-[560px] rounded-full bg-accent/10 blur-3xl" />
          <div className="relative animate-reveal">
            <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-primary/15 bg-primary/5 px-3 py-1.5 text-xs font-bold text-primary"><Sparkles size={13} /> A clearer way to operate</div>
            <h1 className="max-w-[650px] text-balance text-[clamp(3.1rem,7vw,6.6rem)] font-display leading-[.9] tracking-[-0.045em] text-foreground">Know what<br /><em className="text-primary">matters next.</em></h1>
            <p className="mt-7 max-w-lg text-lg leading-8 text-muted-foreground">Northstar gives small operations teams one calm, confident view of the work in motion — and the decisions that need you today.</p>
            <div className="mt-9 flex flex-col gap-3 sm:flex-row">
              <Link href="/sign-in" className="group inline-flex items-center justify-center gap-3 rounded-xl bg-primary px-5 py-3.5 text-sm font-bold text-primary-foreground shadow-[0_8px_20px_rgba(15,102,85,.18)] transition-all hover:-translate-y-0.5 hover:shadow-[0_12px_26px_rgba(15,102,85,.24)]" data-testid="link-home-primary-cta">Enter your workspace <ArrowRight size={17} className="transition-transform group-hover:translate-x-1" /></Link>
              <Link href="/sign-up" className="inline-flex items-center justify-center rounded-xl border border-border bg-card px-5 py-3.5 text-sm font-bold transition-colors hover:bg-muted" data-testid="link-home-create-account">Create an account</Link>
            </div>
            <div className="mt-7 flex items-center gap-2 text-xs text-muted-foreground"><LockKeyhole size={14} className="text-primary" /> Your workspace is private by default.</div>
          </div>
          <div className="relative animate-reveal animate-reveal-1">
            <div className="absolute -right-10 -top-10 size-28 rounded-full border border-accent/35" />
            <div className="grid-paper relative rounded-[2rem] border border-border p-4 shadow-[0_30px_70px_rgba(38,59,52,.12)] sm:p-6">
              <div className="rounded-2xl border border-border bg-card p-5 sm:p-7">
                <div className="flex items-start justify-between"><div><p className="text-xs font-bold uppercase tracking-[.16em] text-muted-foreground">Today · Monday</p><h2 className="mt-2 text-2xl font-bold tracking-tight">Good morning, Maya.</h2></div><span className="grid size-9 place-items-center rounded-full bg-accent/25 text-primary"><Sparkles size={16} /></span></div>
                <div className="mt-7 grid grid-cols-2 gap-3">
                  <div className="rounded-xl bg-primary p-4 text-primary-foreground"><p className="text-xs opacity-70">Open requests</p><p className="mt-2 text-3xl font-bold">18</p><p className="mt-1 text-xs text-accent">↑ 12.4% this week</p></div>
                  <div className="rounded-xl bg-secondary p-4"><p className="text-xs text-muted-foreground">Active users</p><p className="mt-2 text-3xl font-bold">2,840</p><p className="mt-1 text-xs font-semibold text-primary">On target</p></div>
                </div>
                <div className="mt-4 rounded-xl border border-border p-4"><div className="flex justify-between text-sm font-bold"><span>Weekly operating goal</span><span className="text-primary">72%</span></div><div className="mt-3 h-2 overflow-hidden rounded-full bg-muted"><div className="h-full w-[72%] rounded-full bg-accent" /></div><p className="mt-3 text-xs text-muted-foreground">13 of 18 priorities closed</p></div>
                <div className="mt-5 space-y-3">{['Access review completed', 'Vendor packet is ready', 'New teammate invited'].map((item, index) => <div key={item} className="flex items-center gap-3 text-sm"><span className={`grid size-6 place-items-center rounded-full ${index === 2 ? 'bg-accent/20 text-primary' : 'bg-primary/10 text-primary'}`}>{index === 2 ? <ArrowRight size={12} /> : <Check size={13} />}</span><span className={index === 0 ? 'text-foreground' : 'text-muted-foreground'}>{item}</span><span className="ml-auto font-mono-ui text-[10px] text-muted-foreground">{index === 0 ? '09:42' : index === 1 ? '10:15' : 'NEXT'}</span></div>)}</div>
              </div>
            </div>
          </div>
        </section>
        <section className="border-y border-border bg-card/55">
          <div className="mx-auto grid max-w-7xl gap-8 px-5 py-12 sm:px-8 md:grid-cols-3 lg:px-10">
            {[['01', 'The signal, not the noise', 'A focused overview that keeps the day’s priorities in view.'], ['02', 'Small team, shared context', 'Make progress legible to everyone without another status meeting.'], ['03', 'Ready when you are', 'A secure, private workspace that respects the work behind the work.']].map(([number, title, description]) => <div key={number} className="flex gap-4"><span className="font-mono-ui text-xs text-accent">{number}</span><div><h3 className="font-bold">{title}</h3><p className="mt-2 text-sm leading-6 text-muted-foreground">{description}</p></div></div>)}
          </div>
        </section>
        <section className="mx-auto max-w-7xl px-5 py-16 sm:px-8 lg:px-10 lg:py-24"><div className="max-w-2xl"><p className="font-mono-ui text-xs uppercase tracking-[.18em] text-primary">Built for the daily handoff</p><h2 className="mt-4 text-4xl font-display leading-tight tracking-tight sm:text-5xl">A steady view of a moving operation.</h2><p className="mt-5 text-base leading-7 text-muted-foreground">From the first check-in to the final closeout, Northstar makes the shape of your day visible — with just enough detail to move decisively.</p></div></section>
      </main>
      <footer className="border-t border-border px-5 py-7 sm:px-8 lg:px-10"><div className="mx-auto flex max-w-7xl items-center justify-between text-xs text-muted-foreground"><span>© 2025 Northstar Operations</span><span className="font-mono-ui">Private by design</span></div></footer>
    </div>
  );
}