import { ArrowDownRight, ArrowUpRight, CheckCircle2, Clock3, MoreHorizontal, Plus, UsersRound } from 'lucide-react';
import { getGetDashboardActivityQueryKey, getGetDashboardSummaryQueryKey, getGetDashboardUsersQueryKey, useGetDashboardActivity, useGetDashboardSummary, useGetDashboardUsers } from '@workspace/api-client-react';
import { Link } from 'wouter';
import { QueryError, QuerySkeleton, EmptyState } from '@/components/data-states';

const accentClasses: Record<string, string> = {
  teal: 'bg-primary/10 text-primary',
  green: 'bg-[#dcefe4] text-[#2c7453]',
  amber: 'bg-accent/20 text-[#9a641d]',
  violet: 'bg-[#e8e3f3] text-[#65528c]',
  blue: 'bg-[#dcebf2] text-[#3d7189]',
};

export function DashboardPage() {
  const summary = useGetDashboardSummary({ query: { queryKey: getGetDashboardSummaryQueryKey() } });
  const activity = useGetDashboardActivity({ query: { queryKey: getGetDashboardActivityQueryKey() } });
  const users = useGetDashboardUsers({ query: { queryKey: getGetDashboardUsersQueryKey() } });
  const isLoading = summary.isLoading || activity.isLoading || users.isLoading;
  const hasError = summary.isError || activity.isError || users.isError;

  if (isLoading) return <DashboardSkeleton />;
  if (hasError) return <QueryError onRetry={() => { void summary.refetch(); void activity.refetch(); void users.refetch(); }} label="Your overview is temporarily unavailable." />;

  const metrics = summary.data?.metrics || [];
  const activityItems = activity.data || [];
  const dashboardUsers = users.data || [];
  const progress = summary.data?.weeklyGoal ? Math.min(100, Math.round((summary.data.weeklyProgress / summary.data.weeklyGoal) * 100)) : 0;

  return (
    <div className="space-y-8">
      <div className="flex flex-col justify-between gap-5 border-b border-border pb-7 sm:flex-row sm:items-end">
        <div><p className="font-mono-ui text-[11px] uppercase tracking-[.18em] text-primary">Monday, October 14, 2025</p><h1 className="mt-2 text-3xl font-bold tracking-[-.035em] sm:text-4xl">Good morning, Maya.</h1><p className="mt-2 text-sm text-muted-foreground">Here’s the shape of your operation today.</p></div>
        <button type="button" className="inline-flex items-center justify-center gap-2 self-start rounded-xl bg-primary px-4 py-3 text-sm font-bold text-primary-foreground shadow-sm transition-all hover:-translate-y-0.5 hover:shadow-md sm:self-auto" onClick={() => window.alert('New work item flow coming next.')} data-testid="button-new-work-item"><Plus size={17} /> New work item</button>
      </div>
      <section className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {metrics.map((metric, index) => <MetricCard key={metric.label} metric={metric} index={index} />)}
      </section>
      <section className="grid gap-5 xl:grid-cols-[1.35fr_.65fr]">
        <div className="surface rounded-2xl p-5 sm:p-6">
          <div className="flex items-start justify-between"><div><div className="flex items-center gap-2"><span className="grid size-8 place-items-center rounded-lg bg-primary/10 text-primary"><CheckCircle2 size={17} /></span><h2 className="font-bold">Weekly operating goal</h2></div><p className="mt-3 text-sm text-muted-foreground">You’re making a steady dent in this week’s priorities.</p></div><button type="button" className="rounded-lg p-2 text-muted-foreground hover:bg-muted" aria-label="More goal options" data-testid="button-goal-options"><MoreHorizontal size={18} /></button></div>
          <div className="mt-8 flex items-end justify-between"><div><span className="text-5xl font-bold tracking-[-.06em]">{progress}%</span><span className="ml-2 text-sm text-muted-foreground">complete</span></div><span className="font-mono-ui text-xs text-muted-foreground">{summary.data?.weeklyProgress || 0} / {summary.data?.weeklyGoal || 0} closed</span></div>
          <div className="mt-4 h-3 overflow-hidden rounded-full bg-muted"><div className="h-full rounded-full bg-primary transition-all duration-700" style={{ width: `${progress}%` }} /></div>
          <div className="mt-6 grid grid-cols-3 gap-3">{[['Closed', summary.data?.weeklyProgress || 0, 'text-primary'], ['Remaining', Math.max(0, (summary.data?.weeklyGoal || 0) - (summary.data?.weeklyProgress || 0)), 'text-foreground'], ['On track', 'Yes', 'text-[#9a641d]']].map(([label, value, color]) => <div key={label} className="rounded-xl bg-muted/60 p-3"><p className="text-[11px] text-muted-foreground">{label}</p><p className={`mt-1 text-lg font-bold ${color}`}>{value}</p></div>)}</div>
        </div>
        <div className="surface rounded-2xl p-5 sm:p-6"><div className="flex items-center justify-between"><div><p className="text-xs font-bold uppercase tracking-[.16em] text-muted-foreground">Live now</p><h2 className="mt-1 text-2xl font-bold tracking-tight">{summary.data?.activeUsers ?? 0}<span className="ml-2 text-sm font-medium text-muted-foreground">active users</span></h2></div><span className="grid size-10 place-items-center rounded-xl bg-accent/20 text-[#9a641d]"><UsersRound size={18} /></span></div><div className="mt-7 flex items-end gap-1.5"><div className="h-10 flex-1 rounded-t-md bg-primary/20" /><div className="h-16 flex-1 rounded-t-md bg-primary/25" /><div className="h-12 flex-1 rounded-t-md bg-primary/30" /><div className="h-20 flex-1 rounded-t-md bg-primary/45" /><div className="h-14 flex-1 rounded-t-md bg-primary/50" /><div className="h-24 flex-1 rounded-t-md bg-primary" /><div className="h-20 flex-1 rounded-t-md bg-primary/75" /><div className="h-[6.5rem] flex-1 rounded-t-md bg-primary/55" /><div className="h-[5.25rem] flex-1 rounded-t-md bg-primary/40" /></div><div className="mt-3 flex justify-between text-[10px] text-muted-foreground"><span>08:00</span><span>Now</span></div><div className="mt-5 border-t border-border pt-4 text-xs text-muted-foreground"><span className="mr-1.5 inline-block size-1.5 rounded-full bg-primary" /> Usage is up <strong className="text-primary">8.2%</strong> since last week</div></div>
      </section>
      <section className="grid gap-5 xl:grid-cols-[1.1fr_.9fr]">
        <div className="surface overflow-hidden rounded-2xl"><div className="flex items-center justify-between border-b border-border px-5 py-5 sm:px-6"><div><h2 className="font-bold">Recent activity</h2><p className="mt-1 text-xs text-muted-foreground">The latest movement across your workspace.</p></div><button type="button" className="text-xs font-bold text-primary hover:underline" data-testid="button-view-all-activity">View all</button></div>{activityItems.length ? <div className="divide-y divide-border">{activityItems.slice(0, 5).map((item) => <ActivityRow key={item.id} item={item} />)}</div> : <div className="p-5"><EmptyState title="No recent activity" description="When your team starts moving, you’ll see it here." /></div>}</div>
        <div className="surface overflow-hidden rounded-2xl"><div className="flex items-center justify-between border-b border-border px-5 py-5 sm:px-6"><div><h2 className="font-bold">Team users</h2><p className="mt-1 text-xs text-muted-foreground">People with workspace access.</p></div><Link href="/users" className="text-xs font-bold text-primary hover:underline" data-testid="link-view-team">View directory</Link></div>{dashboardUsers.length ? <div className="divide-y divide-border">{dashboardUsers.slice(0, 5).map((user) => <div key={user.id} className="flex items-center gap-3 px-5 py-3.5 sm:px-6" data-testid={`row-dashboard-user-${user.id}`}><span className="grid size-8 place-items-center rounded-full bg-secondary text-[11px] font-bold text-primary">{user.initials}</span><div className="min-w-0 flex-1"><p className="truncate text-sm font-semibold">{user.name}</p><p className="truncate text-xs text-muted-foreground">{user.role}</p></div><span className={`rounded-full px-2 py-1 text-[10px] font-bold capitalize ${user.status === 'active' ? 'bg-[#dcefe4] text-[#2c7453]' : user.status === 'invited' ? 'bg-accent/20 text-[#9a641d]' : 'bg-muted text-muted-foreground'}`}>{user.status}</span></div>)}</div> : <div className="p-5"><EmptyState title="No team users yet" description="Invite teammates to start sharing context." /></div>}</div>
      </section>
    </div>
  );
}

function MetricCard({ metric, index }: { metric: { label: string; value: string; change: string; trend: string; accent: string }; index: number }) {
  const TrendIcon = metric.trend === 'down' ? ArrowDownRight : metric.trend === 'up' ? ArrowUpRight : Clock3;
  return <div className={`surface animate-reveal animate-reveal-${Math.min(index + 1, 3)} rounded-2xl p-5 transition-transform duration-200 hover:-translate-y-0.5`} data-testid={`card-metric-${metric.label.toLowerCase().replaceAll(' ', '-')}`}><div className="flex items-start justify-between"><p className="text-sm font-semibold text-muted-foreground">{metric.label}</p><span className={`grid size-8 place-items-center rounded-lg ${accentClasses[metric.accent] || accentClasses.teal}`}><TrendIcon size={16} /></span></div><p className="mt-5 text-3xl font-bold tracking-[-.04em]">{metric.value}</p><p className="mt-2 flex items-center gap-1 text-xs font-semibold text-muted-foreground"><span className={metric.trend === 'down' ? 'text-destructive' : metric.trend === 'neutral' ? 'text-muted-foreground' : 'text-primary'}>{metric.change}</span><span>vs last period</span></p></div>;
}

function ActivityRow({ item }: { item: { id: string; actor: string; initials: string; action: string; target: string; timestamp: string; tone: string } }) {
  return <div className="flex items-start gap-3 px-5 py-4 sm:px-6" data-testid={`row-activity-${item.id}`}><span className={`grid size-8 shrink-0 place-items-center rounded-full text-[10px] font-bold ${accentClasses[item.tone] || accentClasses.teal}`}>{item.initials}</span><div className="min-w-0 flex-1 text-sm leading-5"><p><strong>{item.actor}</strong> <span className="text-muted-foreground">{item.action}</span> <strong>{item.target}</strong></p><p className="mt-1 flex items-center gap-1 text-[11px] text-muted-foreground"><Clock3 size={11} /> {item.timestamp}</p></div></div>;
}

function DashboardSkeleton() {
  return <div className="space-y-8"><div className="animate-pulse border-b border-border pb-7"><div className="h-3 w-44 rounded bg-muted" /><div className="mt-3 h-10 w-72 rounded bg-muted" /></div><div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4"><QuerySkeleton lines={4} /></div><QuerySkeleton lines={2} /></div>;
}