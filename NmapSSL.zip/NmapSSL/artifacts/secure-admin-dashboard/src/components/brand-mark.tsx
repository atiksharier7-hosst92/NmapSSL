import { Link } from 'wouter';

export function BrandMark({ compact = false }: { compact?: boolean }) {
  return (
    <Link href="/" className="group flex items-center gap-3" data-testid="link-brand-home">
      <span className="grid size-9 shrink-0 place-items-center rounded-xl bg-primary text-primary-foreground shadow-sm transition-transform duration-200 group-hover:-rotate-3">
        <span className="grid grid-cols-2 gap-1">
          <i className="block size-2 rounded-[2px] bg-primary-foreground" />
          <i className="block size-2 rounded-[2px] bg-primary-foreground" />
          <i className="block size-2 rounded-[2px] bg-primary-foreground" />
          <i className="block size-2 rounded-[2px] bg-accent" />
        </span>
      </span>
      {!compact && (
        <span className="leading-none">
          <span className="block text-[15px] font-bold tracking-[-0.03em] text-foreground">Northstar</span>
          <span className="mt-1 block text-[9px] font-bold uppercase tracking-[0.2em] text-muted-foreground">Operations</span>
        </span>
      )}
    </Link>
  );
}