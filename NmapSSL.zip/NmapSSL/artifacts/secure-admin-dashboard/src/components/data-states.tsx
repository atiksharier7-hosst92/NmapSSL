import { AlertCircle, ArrowUpRight, RefreshCw } from 'lucide-react';

export function QuerySkeleton({ lines = 3 }: { lines?: number }) {
  return (
    <div className="space-y-4" aria-label="Loading" data-testid="status-loading">
      {Array.from({ length: lines }).map((_, index) => (
        <div key={index} className="animate-pulse rounded-xl border border-border bg-card p-4">
          <div className="h-3 w-24 rounded bg-muted" />
          <div className="mt-3 h-7 w-32 rounded bg-muted" />
          <div className="mt-4 h-2 w-full rounded bg-muted" />
        </div>
      ))}
    </div>
  );
}

export function QueryError({ onRetry, label = 'We could not load this view.' }: { onRetry?: () => void; label?: string }) {
  return (
    <div className="surface flex min-h-40 flex-col items-center justify-center rounded-2xl px-5 py-8 text-center" data-testid="status-error">
      <span className="mb-3 grid size-10 place-items-center rounded-full bg-destructive/10 text-destructive"><AlertCircle size={18} /></span>
      <p className="font-semibold">{label}</p>
      <p className="mt-1 max-w-sm text-sm text-muted-foreground">Check your connection, then give it another try.</p>
      {onRetry && (
        <button type="button" onClick={onRetry} className="mt-5 inline-flex items-center gap-2 rounded-lg border border-border bg-background px-3 py-2 text-sm font-semibold transition-colors hover:bg-muted" data-testid="button-retry">
          <RefreshCw size={14} /> Retry
        </button>
      )}
    </div>
  );
}

export function EmptyState({ title, description }: { title: string; description: string }) {
  return (
    <div className="surface flex min-h-40 flex-col items-center justify-center rounded-2xl px-5 py-8 text-center" data-testid="status-empty">
      <span className="mb-3 grid size-10 place-items-center rounded-full bg-secondary text-primary"><ArrowUpRight size={17} /></span>
      <p className="font-semibold">{title}</p>
      <p className="mt-1 max-w-sm text-sm text-muted-foreground">{description}</p>
    </div>
  );
}