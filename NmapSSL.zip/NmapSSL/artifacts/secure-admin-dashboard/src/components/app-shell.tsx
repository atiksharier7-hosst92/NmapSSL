import { useState, type ReactNode } from 'react';
import { useClerk, useUser } from '@clerk/react';
import { useHealthCheck, getHealthCheckQueryKey } from '@workspace/api-client-react';
import { Bell, ChevronDown, CircleHelp, FileBarChart, LayoutDashboard, LogOut, Menu, Settings, ShieldCheck, Users, UserRound, X } from 'lucide-react';
import { Link, useLocation } from 'wouter';
import { BrandMark } from '@/components/brand-mark';

const navItems = [
  { href: '/dashboard', label: 'Overview', icon: LayoutDashboard },
  { href: '/users', label: 'Team users', icon: Users },
  { href: '/reports', label: 'Reports', icon: FileBarChart },
  { href: '/notifications', label: 'Notifications', icon: Bell },
];

const secondaryItems = [
  { href: '/profile', label: 'My profile', icon: UserRound },
  { href: '/settings', label: 'Settings', icon: Settings },
];

export function AppShell({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);
  const { signOut } = useClerk();
  const { user } = useUser();
  const health = useHealthCheck({ query: { queryKey: getHealthCheckQueryKey(), staleTime: 30000 } });
  const displayName = user?.firstName || user?.username || 'Operator';
  const initials = (user?.firstName?.[0] || user?.emailAddresses[0]?.emailAddress?.[0] || 'O').toUpperCase();

  const closeMobile = () => setMobileOpen(false);
  const nav = (items: typeof navItems) => items.map(({ href, label, icon: Icon }) => (
    <Link
      key={href}
      href={href}
      onClick={closeMobile}
      className={`group flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-semibold transition-all duration-200 ${location === href ? 'bg-primary text-primary-foreground shadow-sm' : 'text-sidebar-foreground/70 hover:bg-sidebar-accent hover:text-sidebar-foreground'}`}
      data-testid={`link-nav-${label.toLowerCase().replaceAll(' ', '-')}`}
    >
      <Icon size={17} strokeWidth={location === href ? 2.4 : 1.8} />
      <span>{label}</span>
      {label === 'Notifications' && <span className={`ml-auto size-1.5 rounded-full ${location === href ? 'bg-accent' : 'bg-accent'}`} />}
    </Link>
  ));

  return (
    <div className="min-h-[100dvh] bg-background">
      {mobileOpen && <button type="button" aria-label="Close navigation" onClick={closeMobile} className="fixed inset-0 z-30 bg-foreground/25 backdrop-blur-[2px] lg:hidden" data-testid="button-close-overlay" />}
      <aside className={`fixed inset-y-0 left-0 z-40 flex w-[260px] -translate-x-full flex-col border-r border-sidebar-border bg-sidebar px-4 py-5 text-sidebar-foreground transition-transform duration-300 lg:translate-x-0 ${mobileOpen ? 'translate-x-0' : ''}`}>
        <div className="flex items-center justify-between px-2">
          <BrandMark />
          <button type="button" onClick={closeMobile} className="rounded-lg p-2 text-sidebar-foreground/60 hover:bg-sidebar-accent lg:hidden" data-testid="button-close-navigation"><X size={18} /></button>
        </div>
        <div className="mt-10">
          <p className="px-3 pb-2 text-[10px] font-bold uppercase tracking-[0.18em] text-sidebar-foreground/40">Workspace</p>
          <nav className="space-y-1">{nav(navItems)}</nav>
        </div>
        <div className="mt-8">
          <p className="px-3 pb-2 text-[10px] font-bold uppercase tracking-[0.18em] text-sidebar-foreground/40">Account</p>
          <nav className="space-y-1">{nav(secondaryItems)}</nav>
        </div>
        <div className="mt-auto">
          <div className="mb-5 rounded-xl border border-sidebar-border bg-sidebar-accent/65 p-3.5">
            <div className="flex items-center gap-2 text-xs font-semibold"><ShieldCheck size={15} className="text-primary" /> System status</div>
            <div className="mt-3 flex items-center gap-2 text-[11px] text-sidebar-foreground/60" data-testid="status-system">
              <span className={`size-1.5 rounded-full ${health.isError ? 'bg-destructive' : 'animate-pulse-soft bg-primary'}`} />
              {health.isError ? 'Needs attention' : 'All systems operational'}
            </div>
          </div>
          <div className="flex items-center gap-3 border-t border-sidebar-border px-2 pt-4">
            <span className="grid size-9 place-items-center rounded-full bg-accent text-sm font-bold text-accent-foreground">{initials}</span>
            <div className="min-w-0 flex-1"><p className="truncate text-sm font-semibold">{displayName}</p><p className="truncate text-[11px] text-sidebar-foreground/55">{user?.primaryEmailAddress?.emailAddress || 'Workspace member'}</p></div>
            <button type="button" onClick={() => signOut({ redirectUrl: import.meta.env.BASE_URL || '/' })} className="rounded-lg p-2 text-sidebar-foreground/55 transition-colors hover:bg-sidebar-accent hover:text-sidebar-foreground" aria-label="Log out" data-testid="button-logout"><LogOut size={16} /></button>
          </div>
        </div>
      </aside>
      <div className="lg:pl-[260px]">
        <header className="sticky top-0 z-20 flex h-[72px] items-center justify-between border-b border-border bg-background/90 px-5 backdrop-blur-xl sm:px-8 lg:px-10">
          <div className="flex items-center gap-3">
            <button type="button" onClick={() => setMobileOpen(true)} className="rounded-lg p-2 text-muted-foreground hover:bg-muted lg:hidden" aria-label="Open navigation" data-testid="button-open-navigation"><Menu size={20} /></button>
            <div className="hidden items-center gap-2 text-xs text-muted-foreground sm:flex"><CircleHelp size={15} /><span>Operations workspace</span></div>
          </div>
          <div className="flex items-center gap-3">
            <Link href="/notifications" className="relative rounded-lg p-2 text-muted-foreground transition-colors hover:bg-muted hover:text-foreground" aria-label="Notifications" data-testid="link-header-notifications"><Bell size={19} /><span className="absolute right-1.5 top-1.5 size-1.5 rounded-full bg-accent" /></Link>
            <Link href="/profile" className="flex items-center gap-2 rounded-xl p-1.5 pr-2 transition-colors hover:bg-muted" data-testid="link-header-profile"><span className="grid size-8 place-items-center rounded-full bg-primary/10 text-xs font-bold text-primary">{initials}</span><ChevronDown size={14} className="text-muted-foreground" /></Link>
          </div>
        </header>
        <main className="mx-auto max-w-[1440px] px-5 py-8 sm:px-8 lg:px-10 lg:py-10">{children}</main>
      </div>
    </div>
  );
}